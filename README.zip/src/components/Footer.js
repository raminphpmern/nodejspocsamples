import * as React from "react";


const Footer = () => {   
    return (
        <footer>            
        <p>Copyright &copy; 2023 All rights reserved</p>
        </footer>
    )
    
}

export default Footer;
