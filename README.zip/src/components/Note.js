// import { DeleteIcon } from 'react-icons/md';

const Note = ({id, text, date, handleDeleteNote }) => {
    return (
        <div className="note">
            <span>{text}</span>
            <div className="note-footer">
                <a href="#" onClick={() => handleDeleteNote(id)}
                className="delete-icon"
                size='1.3em'>Delete</a>
            </div>
        </div>
    )
}

export default Note;