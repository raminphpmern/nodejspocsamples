import * as React from "react";
import * as ReactDOM from "react-dom";
import { DarkModeSwitch } from "react-toggle-dark-mode";
import {
  Container,
  Row,
  Col,
  Form,
  Input,
  Button,
  Navbar,
  Nav,
  NavbarBrand,
  NavLink,
  NavItem,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
} from "reactstrap";
import logo from "../images/notes-list-logo.png";

// <div><DarkModeSwitch style={{ marginBottom: '2rem', width: '100px'}} checked={isDarkMode} onChange={toggleDarkMode}
//  size={120}  /></div>
//         const [isDarkMode, setDarkMode ] = React.useState(false);

// const toggleDarkMode = (checked: boolean) => {
//     setDarkMode(checked);
// }

const AVATAR =
  "https://www.gravatar.com/avatar/429e504af19fc3e1cfa5c4326ef3394c?s=240&d=mm&r=pg";

const Header = () => (
  <>
  <div className="header">
    <header>
      <Navbar
        fixed="top"
        color="light"
        light
        expand="xs"
        className="header-bar border-bottom border-gray"
        style={{ height: 80 }}
      >
        <Container>
          <Row noGutters className="position-relative w-100 align-items-center">
            <Col className="d-none d-lg-flex justify-content-start">
              <h1>Manage Notes</h1>
              {/* <Nav className="mrx-auto" navbar>
      <NavItem className="d-flex align-items-center">
        <NavLink className="font-weight-bold" href="/">
          <img
            src={AVATAR}
            alt="avatar"
            className="img-fluid rounded-circle"
            style={{ width: 36 }}
          />
        </NavLink>
      </NavItem>

      <NavItem className="d-flex align-items-center">
        <NavLink className="font-weight-bold" href="/">
          Home
        </NavLink>
      </NavItem>

      <NavItem className="d-flex align-items-center">
        <NavLink className="font-weight-bold" href="/">
          Electronics
        </NavLink>
      </NavItem>

      <UncontrolledDropdown
        className="d-flex align-items-center"
        nav
        inNavbar
      >
        <DropdownToggle className="font-weight-bold" nav caret>
          fashion
        </DropdownToggle>
        <DropdownMenu right>
          <DropdownItem
            className="font-weight-bold text-secondary text-uppercase"
            header
            disabled
          >
            Learn React
          </DropdownItem>
          <DropdownItem divider />
          <DropdownItem>Men</DropdownItem>
          <DropdownItem>Women</DropdownItem>
          <DropdownItem>Baby and Kids</DropdownItem>
        </DropdownMenu>
      </UncontrolledDropdown>
    </Nav> */}
            </Col>

            <Col className="d-flex justify-content-xs-start justify-content-lg-center">
              <NavbarBrand
                className="d-inline-block p-0"
                href="/"
                style={{ width: 80 }}
              >
                <img
                  src={logo}
                  alt="logo"
                  className="position-relative img-fluid" />
              </NavbarBrand>
            </Col>
            <Col className="d-none d-lg-flex justify-content-end">
              {/* <Form inline>
      <Input type="search" className="mr-3" placeholder="Search React Courses" />
      <Button type="submit" color="info" outline>Search</Button>
    </Form> */}

              <Nav className="mrx-auto" navbar>
                <NavItem className="d-flex align-items-center">
                  <NavLink className="font-weight-bold" href="/">
                    Home
                  </NavLink>
                </NavItem>

                <NavItem className="d-flex align-items-center">
                  <NavLink className="font-weight-bold" href="/">
                    Deleted Notes
                  </NavLink>
                </NavItem>
                <NavItem className="d-flex align-items-center">
                  <NavLink className="font-weight-bold" href="/">
                    <img
                      src={AVATAR}
                      alt="avatar"
                      className="img-fluid rounded-circle"
                      style={{ width: 36 }} />
                  </NavLink>
                </NavItem>
              </Nav>

            </Col>
          </Row>
        </Container>
      </Navbar>
    </header>
  </div></>
);

export default Header;
