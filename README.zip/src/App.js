import NotesList from './components/NotesList';
import { useEffect, useState } from 'react';
import {nanoid} from 'nanoid';
import Header from './components/Header';
import Search from './components/Search';
import Footer from './components/Footer';
import './index.css';
import AddNote from './components/AddNote';

const App = () => {
  const [notes, setNotes] = useState([
    {
      id: nanoid(),
      text: "Test 1",
      date: "1/2/2023"
    },
    {
      id: nanoid(),
      text: "Test 2",
      date: "2/2/2023"
    },
    {
      id: nanoid(),
      text: "Test 3",
      date: "1/2/2023"
    },
    ]);

    const [searchText, setSearchText] = useState('');

    const [darkMode, setDarkMode] = useState('');

    //Fetch data from Local Storage
    useEffect(() => {
      const savedNotes = JSON.parse(localStorage.getItem('react-notes-app-data'));

      console.log("Saved Notes is Fetched",savedNotes);
      if(savedNotes) {
        setNotes(savedNotes);
      }
    },[]);

    //Save data in Local Storage
    useEffect(() => {
      localStorage.setItem(
        'react-notes-app-data', //key to access local Storage element
        JSON.stringify(notes))
      }, [notes]);
    
    //Add Note
    const addNote = (text) => {
      console.log(text);
      const date = new Date();
      const newNote = {
        id: nanoid(),
        text: text,
        date: date.toLocaleDateString()
      }

      const newNotes = [...notes, newNote];
      setNotes(newNotes); // updates the state
    }

    //Delete the Note
    // The filter function returns a new array, so we don't have to worry about creating a new array
    // Create a new array with elements NOT having the same ID as the ID passed in, meaning that if it does,
    // It will NOT be included in the array, effectively, deleting it.

    const deleteNote = (id) => {
      const newNotes = notes.filter((note) => note.id !== id);
      setNotes(newNotes);
    }
    
    return (
      <div>
        <div className="container">
        <Header />
        <Search handleSearchNote={setSearchText}/>
        <NotesList 
          notes={notes.filter((note) =>
          note.text.toLowerCase().includes(searchText))}
          handleAddNote={AddNote}
          handleDeleteNote={deleteNote}
          />
        <Footer />
        </div>
      </div>

    );

}

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

export default App;
